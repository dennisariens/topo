# NINO Pisa Edition — QA review report (3 November 2026)

## Verified in this delivery
- Original approved Pisa artwork retained; no new mascot, characters or typography.
- Source-file hashes locked and independently enforced by GitHub CI, PR #72.
- All compositing PNG layers have a 1254 × 1254 shared canvas, with alpha.
- Separate 800 × 800 UV print and kraft-underside textures.
- Three pizza interiors, each 24 frames at 54 ms (1296 ms total).
- The exterior print is facing the correct side of the rotating lid.
- Closed-to-open animation does not crossfade complete source photographs.
- The erroneous repeated cardboard pattern was replaced by subtle uniform kraft grain.
- Reduced-motion static alternative is provided in the offline review page.
- GitHub artwork CI completed successfully on the corrected branch.

## Not independently accepted yet
- Final appearance and hinge alignment require owner review at actual app size.
- No physical iPad Safari test and no Hermes independent signoff.
- No TOPO app code, rewards, scoring or offline learning logic was changed.
- Reconstructed hidden cardboard faces are **derivatives**, not recovered source pixels.

Verdict: **READY FOR OWNER REVIEW — NOT MERGED / NOT RELEASED**.

## Additional observation
70° opening keeps the rendered moving lid within the shared canvas; the 105° pose clipped at the top and was rejected. Subtle differences between independently rendered source-camera viewpoints can remain visible; verify at target sizes.
