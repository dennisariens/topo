# NINO / TOPO — Pisa Edition
## Final artwork review package — source preserving v2

This is **not a redesign**. All original Pisa illustration and the three approved
pizza images are derived from the approved `art/nino-pizza-rewards-20261024` sources.

Assets: one matched tray, stationary original cardboard rim, printed exterior lid,
neutral kraft underside, three pizza interiors and five proof frames per flavor.

The opening is made from a perspective-projected moving lid (105°), not from a
closed/open photograph crossfade. The pixel-only texture behind the pizza and the
occluded underside were reconstructed in matching kraft; these were not visible
in the original flattened masters.

Review `proof/contact-sheet.png` and `review.html` before approving. This package
is a **design review candidate**, not a claim of completed independent Hermes QA.
Do not merge or replace the existing static reward fallback until acceptance.

Source references:
- GitHub issue #31
- GitHub PR #29 (existing static pizza implementation)
- GitHub PR #63 (rejected first rig)
- GitHub PR #72 (source-preserving build branch)

## Layer contract
All PNGs in `layers/` share the same 1254 × 1254 canvas.
The two 800 × 800 UV textures in `textures/` are auxiliary source maps, not registered layers.
